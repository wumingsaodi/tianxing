//
//  CircleRecomedTableVC.swift
//  TianXin
//
//  Created by SDS on 2020/10/2.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit

class CircleRecomedTableVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.addSubview(tableView)
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    lazy var tableView:SDSTableView = {
        let tab =  SDSTableView.CreateTableView().sdsNumOfRows(block: { (_) -> Int in
            return 4
        }).sdsRegisterCell(cellClass: CircleRecomedTableCell.className(), cellBlock: { (indexPath, cell) in
            let ncell = cell as! CircleRecomedTableCell
            
        }, height: { (indexPath) -> CGFloat in
            return 440
        }).sdsDidSelectCell { (indexPath) in
            
        }
        return tab
    }()
}




















