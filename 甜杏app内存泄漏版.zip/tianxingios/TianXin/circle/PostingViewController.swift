//
//  PostingViewController.swift
//  TianXin
//
//  Created by pretty on 10/14/20.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa
import ZLPhotoBrowser
import Photos

class PostingViewController: UIViewController {
    @IBOutlet weak var sendButton: UIButton!
    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var placeholderLabel: UILabel!
    @IBOutlet weak var wordsLimitLabel: UILabel!
    @IBOutlet weak var photoSelectionCollectionView: UICollectionView!
    @IBOutlet weak var avatarSelectionCollectionView: UICollectionView!
    @IBOutlet weak var photoSelectionHeightConstraint: NSLayoutConstraint!
    
    private var photoSelectionFlowLayout: UICollectionViewFlowLayout {
        return photoSelectionCollectionView.collectionViewLayout as! UICollectionViewFlowLayout
    }
    
    lazy var viewModel: PostingViewControllerModel = PostingViewControllerModel()
    private let selectedPhotos = BehaviorRelay<[PhotoSelectionCellViewModel]>(value: [PhotoSelectionCellViewModel(image: R.image.add(), type: .add)])
    private var selectedAssets: [PHAsset] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        makeUI()
        bindViewModel()
    }
    
    private func bindViewModel() {
        // 关联UI
        textView.rx.text.changed
            .asObservable()
            .distinctUntilChanged()
            .map { !($0?.isEmpty ?? true) }
            .bind(to: placeholderLabel.rx.isHidden)
            .disposed(by: rx.disposeBag)
        // viewmodel
        let input = PostingViewControllerModel.Input(
        )
        let output = viewModel.transform(input: input)
        
        // 绑定photo selection collectionview
        selectedPhotos
            .asDriver()
            .drive(photoSelectionCollectionView.rx.items(cellIdentifier: "\(PhotoSelectionCell.self)", cellType: PhotoSelectionCell.self)) {
                index, viewModel, cell in
                cell.bind(viewModel)
            }
            .disposed(by: rx.disposeBag)
        // 绑定 photo selection height
        let lineHeight = self.photoSelectionFlowLayout.itemSize.width + self.photoSelectionFlowLayout.minimumLineSpacing
        selectedPhotos.map {
            CGFloat(($0.count + 2) / 3) * lineHeight
        }
        .bind(to: photoSelectionHeightConstraint.rx.constant)
        .disposed(by: rx.disposeBag)
        // 点击图片
        photoSelectionCollectionView.rx.modelSelected(PhotoSelectionCellViewModel.self)
            .asObservable()
            .subscribe(onNext: { [weak self] model in
                switch model.type {
                case .add: self?.openPhotoBrowser()
                case .origin: break
                }
            })
            .disposed(by: rx.disposeBag)
        
    }
    // 打开相册
    private func openPhotoBrowser() {
        let ps = ZLPhotoPreviewSheet(selectedAssets: selectedAssets)
        ps.selectImageBlock = {[weak self](images, assets, isOriginal) in
            self?.selectedAssets = assets
            var imageModes = images.map {PhotoSelectionCellViewModel(image: $0, type: .origin)}
            if images.count < 9 {
                imageModes.append(PhotoSelectionCellViewModel(image: R.image.add(), type: .add))
            }
            self?.selectedPhotos.accept(imageModes)
        }
        ps.showPreview(animate: true, sender: self)
    }
}


extension PostingViewController {
    func makeUI() {
        self.navigationItem.title = "发帖"
        hidesBottomBarWhenPushed = true
        self.view.backgroundColor = .white
        // 最多选择9张照片
        ZLPhotoConfiguration.default().maxSelectCount = 9
        //
        photoSelectionFlowLayout.itemSize = .init(width: 94, height: 94)
    }
}

extension PostingViewController {
    enum PhotoSelectionType {
        case add
        case origin
    }
    struct PhotoSelectionCellViewModel {
        let type: PhotoSelectionType
        let image = BehaviorRelay<UIImage?>(value: nil)
        
        init(image: UIImage? = nil, type: PhotoSelectionType) {
            self.type = type
            self.image.accept(image)
        }
    }
}
