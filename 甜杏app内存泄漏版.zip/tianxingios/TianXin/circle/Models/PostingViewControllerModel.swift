//
//  PostingViewControllerModel.swift
//  TianXin
//
//  Created by pretty on 10/15/20.
//  Copyright © 2020 SDS. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa

class PostingViewControllerModel: NSObject, ViewModelType {
    
    struct Input {
        
    }
    struct Output {
//        let selectedPhotos: Driver<UIImage?>
    }
    func transform(input: Input) -> Output {
        
       return Output(
            
       )
    }
}
