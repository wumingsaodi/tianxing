//
//  CircleHomeVC.swift
//  TianXin
//
//  Created by SDS on 2020/10/1.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit

class CircleHomeVC: SDSBaseVC {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = true
        setUI()
        
        FloatingButton.default.show(in: self.view)
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidAppear(animated)
        selectedTittlesv.scollToIndex(index: 0)
        self.selectedVCs.scollToIndex(index: 0)
    }
    func setUI() {
        let whiteBgV = UIView()
        whiteBgV.backgroundColor = .white
        self.view.addSubview(whiteBgV)
        whiteBgV.snp.makeConstraints { (make) in
            make.left.top.right.equalToSuperview()
            make.height.equalTo(KnavHeight + 20 )
        }
       whiteBgV.addSubview(searchBut)
        searchBut.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.centerY.equalToSuperview().offset(20)
            make.size .equalTo(CGSize(width: 300, height: 29))
        }
        //
        let tuijianv = ceatetuiJianView()
        self.view.addSubview(tuijianv)
        tuijianv.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(10)
            make.right.equalToSuperview().offset(-10)
            make.top.equalTo(whiteBgV.snp.bottom).offset(10)
            make.height.equalTo(132)
        }
        //
        self.view.addSubview(selectedTittlesv)
        selectedTittlesv.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalTo(tuijianv.snp.bottom).offset(15)
            make.height.equalTo(30)
        }
        //
        self.view.addSubview(selectedVCs)
        selectedVCs.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview()
            make.top.equalTo(selectedTittlesv.snp.bottom)
        }
    }
    lazy var selectedTittlesv:SDSScrollTitlesView = {
        let titlev = SDSScrollTitlesView.init(ttles: ["我的","推荐"], width: 60) {[weak self] (index, cell) in
            self?.selectedVCs.scollToIndex(index: index)
        }
        return titlev
    }()
    lazy var selectedVCs:SDSScrollColltionView = {
        let vcs = [CircleMineVC(),CircleRecomedTableVC()]
        let vcsv = SDSScrollColltionView.init(VCs: vcs) { (index) in
            //
            self.selectedTittlesv.scollToIndex(index: index)
        }
        return vcsv
    }()
    func ceatetuiJianView() -> UIView {
        let bgv = UIView()
        bgv.backgroundColor = .white
        let lab  = UILabel.createLabWith(title: "推荐圈子", titleColor: .black, font: .pingfangSC(20))
        let imgv = UIImageView(image: UIImage(named: "icon_button_xuanzhong"))
        bgv.addSubview(imgv)
        bgv.addSubview(lab)
      
        lab.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(5)
            make.left.equalToSuperview().offset(10)
        }
        imgv.snp.makeConstraints { (make) in
            make.left.equalTo(lab).offset(-2)
            make.centerY.equalTo(lab.snp.bottom)
        }
       let titles = ["kok","达尔。。","技术。。","小黄文","全部"]
        let butw:CGFloat = 50
        let buth:CGFloat = 80
        let margin:CGFloat = (KScreenW - 20 - butw * CGFloat(titles.count)) /  CGFloat(titles.count + 1)
        var x:CGFloat = margin
        let y:CGFloat  = 30
        for i in 0..<5 {
            let  but = createItemBut(url: "", title: titles[i], tag: i)
            bgv.addSubview(but)
            but.snp.makeConstraints { (make) in
                make.top.equalToSuperview().offset(y)
                make.left.equalToSuperview().offset(x)
                make.size.equalTo(CGSize(width: butw, height: buth))
            }
            x += margin + butw
        }
        bgv.cornor(conorType: .allCorners, reduis: 4)
        return bgv
    }
    func  createItemBut(url:String,title:String,tag:Int)->UIView{
        let view = UIView()
        let imgv = UIImageView()
        imgv.cornor(conorType: .allCorners, reduis: 25)
        view.addSubview(imgv)
        let lab = UILabel.createLabWith(title: title, titleColor: nil, font: nil)
        view.addSubview(lab)
        
        imgv.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            make.centerX.equalToSuperview()
            make.size.equalTo(CGSize(width: 50, height: 50))
        }
        lab.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(imgv.snp.bottom).offset(10)
        }
        let tap = UITapGestureRecognizer.init(target: self, action: #selector(tapviewClick(tap:)))
        view.tag = tag
        view.addGestureRecognizer(tap)
        return view
    }
    lazy var  searchBut:UIButton = {
        let but = UIButton.createButWith(title: "请输入你想要找的关键字", titleColor: .gray, font: .pingfangSC(15),image: UIImage(named: "seach")) { (but) in
        
        }
        but.backgroundColor =   .Hex("#f7f8fc") //  baseVCBackGroudColor_grayWhite
        but.cornor(conorType: .allCorners, reduis: 14.5)
        return but
    }()
}
//MARK: - actions
extension CircleHomeVC {
  @objc  func tapviewClick(tap:UITapGestureRecognizer) {
        let view = tap.view!
      if  view.tag == 0 {
            
      }else if view.tag == 1 {
        
        }
    }
}
