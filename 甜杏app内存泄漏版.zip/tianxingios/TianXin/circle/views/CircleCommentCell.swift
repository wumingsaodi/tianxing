//
//  CircleCommentCell.swift
//  TianXin
//
//  Created by SDS on 2020/10/5.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit

class CircleCommentCell: UITableViewCell {
   static let cellH :CGFloat = 92
    override func awakeFromNib() {
        super.awakeFromNib()
       
    }
    func setUI() {
        self.contentView.backgroundColor  = baseVCBackGroudColor_grayWhite
        self.contentView.addSubview(iconv)
        iconv.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(11)
            make.top.equalToSuperview().offset(20)
        }
        self.contentView.addSubview(nameL)
        nameL.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(22)
            make.left.equalTo(iconv.snp.right).offset(8)
        }
        self.contentView.addSubview(timeL)
        timeL.snp.makeConstraints { (make) in
            make.left.equalTo(nameL)
            make.top.equalTo(nameL.snp.bottom).offset(4)
        }
        self.contentView.addSubview(detailL)
        detailL.snp.makeConstraints { (make) in
            make.left.equalTo(nameL)
            make.top.equalTo(timeL.snp.bottom).offset(8)
        }
        self.contentView.addSubview(commentBut)
        commentBut.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(29)
            make.right.equalToSuperview().offset(10)
        }
        self.contentView.addSubview(loveBut)
        loveBut.snp.makeConstraints { (make) in
            make.centerY.equalTo(commentBut)
            make.right.equalTo(commentBut.snp.left).offset(-8)
        }
    }
    lazy var iconv :UIImageView = {
      let imgv = UIImageView()
        imgv.sdsSize = CGSize(width: 34, height: 34)
        imgv.cornor(conorType: .allCorners, reduis: 17)
        return imgv
    }()
    lazy var nameL:UILabel = {
        let  lab = UILabel.createLabWith(title: "", titleColor: .Hex("#080808"), font: .pingfangSC(14))
        return lab
    }()
    lazy var loveBut:UIButton = {
        let but = UIButton.createButWith(title: "0", titleColor: .Hex("#959595"), font: .pingfangSC(13), image: UIImage(named: "")) { (but) in
            
        }
        but.setButType(type: .imgLeft, padding: 8)
        return but
    }()
    lazy var commentBut:UIButton = {
        let but = UIButton.createButWith(title: "0", titleColor: .Hex("#959595"), font: .pingfangSC(13), image: UIImage(named: "")) { (but) in
                 
             }
        but.setButType(type: .imgLeft, padding: 8)
             return but
    }()
    lazy var timeL:UILabel = {
        let lab = UILabel.createLabWith(title: "", titleColor: .Hex("#9c9c9c"), font: .pingfangSC(11))
        return lab
    }()
    lazy var detailL:UILabel = {
          let  lab = UILabel.createLabWith(title: "", titleColor: .Hex("#080808"), font: .pingfangSC(17))
        return lab
      }()
}
