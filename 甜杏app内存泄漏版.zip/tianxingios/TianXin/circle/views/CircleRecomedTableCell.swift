//
//  CircleRecomedTableCell.swift
//  TianXin
//
//  Created by SDS on 2020/10/2.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit

class CircleRecomedTableCell: UITableViewCell {
    var imgVH:CGFloat = .zero
    var commenttableH:CGFloat = CircleCommentCell.cellH
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func setUI(){
        let bgv = UIView()
        bgv.backgroundColor = .white
        bgv.cornor(conorType: .allCorners, reduis: 3)
        self.contentView.addSubview(bgv)
        bgv.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(10)
            make.right.equalToSuperview().offset(-10)
            make.bottom.equalToSuperview()
            make.top.equalToSuperview().offset(10)
        }
        //
         bgv .addSubview(iconv)
        iconv.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(14)
            make.top.equalToSuperview().offset(10)
            make.size.equalTo(CGSize(width: 44, height: 44))
        }
        //
        bgv.addSubview(nameL)
        nameL.snp.makeConstraints { (make) in
            make.centerY.equalTo(iconv)
            make.left.equalTo(iconv).offset(10)
        }
        //
        bgv.addSubview(titleL)
        titleL.snp.makeConstraints { (make) in
            make.left.equalTo(iconv)
            make.right.equalToSuperview().offset(-10)
            make.top.equalTo(iconv.snp.bottom).offset(10)
        }
        //
        bgv.addSubview(imgvs)
        imgvs.snp.makeConstraints { (make) in
            make.left.equalTo(iconv)
            make.right.equalTo(titleL)
            make.top.equalTo(titleL.snp.bottom).offset(5)
            make.height.equalTo(imgVH)
        }
        //
        bgv.addSubview(commentTableView)
        commentTableView.snp.makeConstraints { (make) in
            make.top.equalTo(imgvs.snp.bottom).offset(5)
            make.left.right.equalTo(imgvs)
            make.height.equalTo(commenttableH)
        }
    }
    lazy var commentTableView:SDSTableView = {
        let tab = SDSTableView.CreateTableView().sdsNumOfRows(block: { (_) -> Int in
            return 1
        }).sdsRegisterCell(cellClass: CircleCommentCell.className(), cellBlock: { (indePath, cell) in
            let ncell = cell as! CircleCommentCell
            
        }, height: { (_) -> CGFloat in
            return CircleCommentCell.cellH
        }).sdsDidSelectCell { (ndexPath) in
            
        }
        return tab
    }()
    lazy var  imgvs :UIView = {
      let view = UIView()
        return view
    }()
    lazy  var iconv:UIImageView = {
    let imgv = UIImageView()
        imgv.cornor(conorType: .allCorners, reduis: 22, borderWith: 1, borderColor: mainYellowColor)
        return imgv
    }()
    lazy var nameL:UILabel = {
        let lab = UILabel.createLabWith(title: "", titleColor: .Hex("5c5c5c"), font: .boldSystemFont(ofSize: 18))
        return lab
    }()
    lazy var guanZhuBut:UIButton = {
        let but = UIButton.createButWith(title: "已关注", titleColor: mainYellowColor, font: .pingfangSC(14), image: UIImage(named: ""),  backGroudColor: .clear) { (but) in
        
        }
        but.sdsSize = CGSize(width: 52, height: 24)
        return but
    }()
    var titleL:UILabel = {
        let lab = UILabel.createLabWith(title: "", titleColor: nil, font: .pingfangSC(15))
        lab.numberOfLines = 0
        return lab
    }()
    func createTabLab(title:String,color:UIColor,backgroudColor:UIColor)->UILabel{
        let lab = UILabel.createLabWith(title: title, titleColor: color, font: .pingfangSC(12), cornorRaduis: 4, cornorType: .allCorners, padding: UIEdgeInsets(top: 2, left: 2, bottom: 2, right: 2))
        return  lab
    }
    func guanzhuBut(slected:Bool){
        if slected {
            guanZhuBut.setImage(nil, for: .normal)
            guanZhuBut.setTitle("已关注", for: .normal)
            guanZhuBut.cornor(conorType: .allCorners, reduis: guanZhuBut.sdsW*0.5, borderWith: 0, borderColor: .clear)
            guanZhuBut.isEnabled = false
            guanZhuBut.backgroundColor = .Hex("f33f3")
            guanZhuBut.setTitleColor(.Hex("b2b2b4"), for: .normal)
        }else{
             guanZhuBut.setTitle("关注", for: .normal)
            guanZhuBut.setButType(type: .imgLeft, padding: 10)
            guanZhuBut.setImage(UIImage(named: ""), for: .normal)
            guanZhuBut.cornor(conorType: .allCorners, reduis: guanZhuBut.sdsW*0.5, borderWith: 1, borderColor: mainYellowColor)
                      guanZhuBut.isEnabled = true
                      guanZhuBut.backgroundColor = .Hex("f33f3")
                      guanZhuBut.setTitleColor(.Hex("b2b2b4"), for: .normal)
           
        }
    }
}
