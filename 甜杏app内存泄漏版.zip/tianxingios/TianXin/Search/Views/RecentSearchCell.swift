//
//  RecentSearchCell.swift
//  TianXin
//
//  Created by pretty on 10/10/20.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit
import RxGesture
import RxSwift
import RxCocoa

class RecentSearchCell: UICollectionViewCell {
    @IBOutlet weak var deleteButton: UIButton!
    @IBOutlet weak var titleLabel: UILabel!
    
    func bind(_ model: RecentSearchCellViewModel, onDelete: BehaviorRelay<Int>? = nil) {
        model.deleting.map{ !$0 }.asDriver(onErrorJustReturn: true)
            .drive(deleteButton.rx.isHidden)
            .disposed(by: rx.disposeBag)
        model.title.asDriver().drive(titleLabel.rx.text).disposed(by: rx.disposeBag)
        self.titleLabel.superview?.rx.longPressGesture()
            .when(.began)
            .subscribe(onNext: { _ in
                model.deleting.toggle()
            }).disposed(by: rx.disposeBag)
        deleteButton.rx.tap.asObservable().subscribe(onNext: {
            onDelete?.accept(model.item.id)
        }).disposed(by: rx.disposeBag)
       
    }
}
