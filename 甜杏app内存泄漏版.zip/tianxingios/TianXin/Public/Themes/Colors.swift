//
//  Colors.swift
//  TianXin
//
//  Created by pretty on 10/7/20.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit

extension UIColor {
    static let primary = UIColor(hex: 0xFBB65C)
    static let backgroud = UIColor(hex: 0xF7F8FA)
    static let placeholder = UIColor(hex: 0x999999)
    static let subtitle = UIColor(hex: 0x636364)
    static let text = UIColor(red: 0.53, green: 0.51, blue: 0.49, alpha: 1)
    static let grey61 = UIColor(white: 0.61, alpha: 1)
    static let grey22 = UIColor(white: 0.22, alpha: 1)
    static let grey95 = UIColor(white: 0.95, alpha: 1)
}

