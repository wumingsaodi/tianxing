//
//  UITableView+RX.swift
//  TianXin
//
//  Created by pretty on 10/9/20.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit
import RxCocoa
import RxSwift

extension Reactive where Base: UITableView {
    var allowsMultipleSelection: Binder<Bool> {
        return Binder<Bool>(self.base) {
            tableView, active in
            tableView.isEditing = active
            tableView.allowsMultipleSelection = active
            tableView.allowsMultipleSelectionDuringEditing = active
        }
    }
}
