//
//  UITableView.swift
//  TianXin
//
//  Created by pretty on 10/7/20.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit

extension UITableView {
    func registerNib<T: UITableViewCell>(type: T.Type) {
        self.register(UINib(nibName: "\(type)", bundle: nil), forCellReuseIdentifier: "\(type)")
    }
    func registerHeaderFooterViewNib<T: UITableViewHeaderFooterView>(type: T.Type) {
        self.register(UINib(nibName: "\(type)", bundle: nil), forHeaderFooterViewReuseIdentifier: "\(type)")
    }
    func dequeueReusableCell<T: UITableViewCell>(for indexPath: IndexPath) -> T {
        return self.dequeueReusableCell(withIdentifier: "\(T.self)", for: indexPath) as! T
    }
    func dequeueReusableHeaderFooterView<T: UITableViewHeaderFooterView>() -> T {
        return self.dequeueReusableHeaderFooterView(withIdentifier: "\(T.self)") as! T
    }
}
