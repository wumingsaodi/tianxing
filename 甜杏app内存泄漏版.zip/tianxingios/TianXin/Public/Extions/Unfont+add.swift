//
//  Unfont+add.swift
//  TianXin
//
//  Created by SDS on 2020/9/21.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit

extension UIFont {
    static func pingfangSC(_ fontSize:CGFloat)->UIFont{
        return UIFont.systemFont(ofSize: fontSize)
    }
}
