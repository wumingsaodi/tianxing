//
//  UserApi.swift
//  TianXin
//
//  Created by pretty on 10/12/20.
//  Copyright © 2020 SDS. All rights reserved.
//

import Foundation
import Moya

enum UserApi {
    // 收藏列表
    case movieFavorites(currPage: Int, pageSize: Int)
    // 收藏
    case addLike(movieId: String, isTopic: Bool)
}

extension UserApi: TargetType {
    var path: String {
        switch self {
        case .movieFavorites: return Configs.Network.User.movieFavorites
        case .addLike: return Configs.Network.User.addLike
        }
    }
    var task: Task {
        var params: [String: Any] = [:]
        switch self {
        case let .movieFavorites(currPage, pageSize):
            params["currPage"] = currPage
            params["pageSize"] = pageSize
        case let .addLike(movieId, isTopic):
            params["movieId"] = movieId
            params["isTopic"] = isTopic ? "1" : "0"
        }
        // 全局处理userid参数
        params["userId"] = LocalUserInfo.share.userId ?? ""
        params = customGenerate(params)
        return .requestParameters(parameters: params, encoding: URLEncoding.default)
    }
    var sampleData: Data {
        return Data()
    }
}
