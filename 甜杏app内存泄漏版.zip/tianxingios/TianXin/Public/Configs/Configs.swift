//
//  Configs.swift
//  TianXin
//
//  Created by pretty on 10/7/20.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit

struct Configs {
    struct App {
        static let bundleIdentifier = "com.tianXin.www.TianXin"
        static let env: Configs.App.Env = .dev
    }
    struct Network {
        static let loggingEnabled = true
        static let baseUrl = "http://tianxing.viphk.ngrok.org"
    }
    struct Dimensions {
        static let cornerRadius: CGFloat = 5
    }
    struct Path {
        static let Documents = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
        static let Tmp = NSTemporaryDirectory()
    }
    
    static let publicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC6amslTkuX0LsXJd8KVkWp1HdppmqrynpS4kykQquQHyEmzunIMJxqdZgul9Fn/VCoj/p9+uesD50QXB4eQCl/sAXM/kFq2fSrVdr7ZgyPIL/pFAhimEmEv0Adg1fasZ7kWbf6OTIitO1BJ0FVDdtJ+3dP4BZMNJ6zDW3EQiLg/QIDAQAB"
}
// app测试环境
extension Configs.App {
    enum Env {
        case dev // 开发环境
        case multivariate // 灰度测试
        case distribution // 正式发布
    }
}

/// 专题相关URL
extension Configs.Network {
    struct Topic {
        // 取消点赞
        static let delMovieILike = "/gl/topic/delMovieILike"
        // 最近常搜
        static let recentSearchVideo = "/gl/topic/recentSearchVideo"
        // 单个最近常搜
        static let delSearchVideo = "/gl/topic/delSearchVideo"
        // 电影点赞
        static let addMovieILike = "/gl/topic/addMovieILike"
        // 专题电影列表
        static let topicMovieList = "/gl/topic/topicMovieList"
        // 观看电影
        static let topicWatchMovie = "/gl/topic/topicWatchMovie"
        // 搜索专题电影名
        static let searchTopicVideo = "/gl/topic/searchTopicVideo"
        // 用户对电影评论回复
        static let addMovieReply = "/gl/topic/addMovieReply"
        // 电影评论回复详情
        static let topicMovieRemarkDetail = "/gl/topic/topicMovieRemarkDetail"
        // 相关推荐电影
        static let refMovieList = "/gl/topic/refMovieList"
        // 批量删除最近搜索
        static let batchDelSearch = "/gl/topic/batchDelSearch"
        // 专题推荐
        static let topicVideoRecommend = "/gl/topic/topicVideoRecommend"
        // 取消电影评论
        static let delMyMovieRemark = "/gl/topic/delMyMovieRemark"
        // 电影评论
        static let addMovieRemark = "/gl/topic/addMovieRemark"
        // 取消电影评论回复
        static let delMyMovieReply = "/gl/topic/delMyMovieReply"
    }
    struct User {
        // 收藏列表
        static let movieFavorites = "/gl/user/myLike"
        // 收藏
        static let addLike = "/gl/user/addLike"
    }
}
