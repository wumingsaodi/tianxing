//
//  HomeDetailViewMoodel.swift
//  TianXin
//
//  Created by SDS on 2020/10/15.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit

class HomeDetailViewMoodel: NSObject {
    func requistMovieDetail(id:String){
        NetWorkingHelper.normalPost(url: api_homeDetail, params: ["id":id,"uuid":getUUID()]) { (dict) in
            
        }

    }
}
