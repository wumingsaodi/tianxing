//
//  HomeViewModel.swift
//  TianXin
//
//  Created by SDS on 2020/9/30.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit

class HomeViewModel: NSObject {
    
    var homeModel:HomeIndexModel?
    func requistCheckUp(version:Double,_ success:@escaping (_ isNeedDown:Int,_ url:String)->Void){
        let params = ["version":version,"os":"ios"] as [String : Any]
        NetWorkingHelper.normalPost(url: api_checkUp, params: params, success: { (dict) in
            success(dict["isReDownload"] as! Int,dict["url"] as! String)
            
        }) { (error) in
            SDSHUD.showError(error.errMsg)
        }
    }
    /**
     获取首页信息
     */
    func RequistHomeIndex(_ success:@escaping ()->Void) {
        NetWorkingHelper.normalPost(url: api_homeindex, params: [:], success: { (dict) in
            let model = HomeIndexModel.deserialize(from: dict)
            self.homeModel = model
            success()
        }) { (error) in
            SDSHUD.showError(error.errMsg)
        }
    }
}
