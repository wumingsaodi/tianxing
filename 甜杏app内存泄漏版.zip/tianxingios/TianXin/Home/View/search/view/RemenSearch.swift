//
//  RemenSearch.swift
//  TianXin
//
//  Created by SDS on 2020/9/22.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit

class RemenSearch: UIView {
    var titles:[String]!
    var didSelectedBlock:((String)->Void)!
    init(frame: CGRect,titles:[String],didSelectedBlock:@escaping (String)->Void) {
        super.init(frame: frame)
        self.backgroundColor = .white
        self.titles = titles
        self.didSelectedBlock = didSelectedBlock
        setUI()
    }
    func  setUI()  {
        
        //
          let imgV = UIImageView.init(image: UIImage(named: "icon_button_xuanzhong"))
         self.addSubview(imgV)
        //
        let  titleLab = UILabel.createLabWith(title: "热门搜索", titleColor: .Hex("#FF3B372B"), font: .pingfangSC(24))
        self.addSubview(titleLab)
        titleLab.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(20)
            make.top.equalToSuperview().offset(22)
        }
      
        //
       
        imgV.snp.makeConstraints { (make) in
            make.centerX.equalTo(titleLab.snp.left)
            make.centerY.equalTo(titleLab.snp.bottom)
        }
        //
        let remenBg = createRemenView()
        self.addSubview(remenBg)
        remenBg.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalTo(titleLab.snp.bottom).offset(20)
        }
        //
        let nodataImg = UIImageView.init(image: UIImage(named: "nodata"))
        self.addSubview(nodataImg)
        nodataImg.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(remenBg.snp.bottom).offset(40)
        }
        //
        let title = "暂未找到“搜素记录”"
        let nodataTitle = UILabel.createLabWith(title: title, titleColor: .Hex("#FFD7D7D7"), font: .pingfangSC(21))
        self.addSubview(nodataTitle)
        nodataTitle.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(nodataImg.snp.bottom).offset(10)
        }
    }
    func createRemenView()->UIView{
        let bg = UIView()
        var x:CGFloat = 30
        var y:CGFloat = 0
       
        let h :CGFloat = 30
        let w:CGFloat = 63
         let margin:CGFloat = (KScreenW - 60 - 63*4)/3
        for i in 0..<titles.count {
            let lab  = UIButton.createButWith(title: titles[i], titleColor: .Hex("#FF87827D"), font: .pingfangSC(15)) { (but) in
                self.didSelectedBlock(but.currentTitle!)
            }
            lab.cornor(conorType: .allCorners, reduis: 15, borderWith: 1, borderColor: mainYellowColor)
//            let lab = UILabel.createLabWith(title: titles[i], titleColor: .Hex("#FF87827D"), font: .pingfangSC(15), cornorRaduis: 15, cornorType: .allCorners, borderWith: 1, borderColor: mainYellowColor)
            bg.addSubview(lab)
            lab.snp.makeConstraints { (make) in
                make.left.equalToSuperview().offset(x)
                make.top.equalToSuperview().offset(y)
                make.size.equalTo(CGSize(width: 63, height: 30))
                if i == titles.count - 1 {
                    make.bottom.equalToSuperview().offset(-4)
                }
            }
            x += margin + w
            if x > KScreenW - 30 - w {
                x = 30
                y += h + 15
            }
        }
        
        return bg
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
