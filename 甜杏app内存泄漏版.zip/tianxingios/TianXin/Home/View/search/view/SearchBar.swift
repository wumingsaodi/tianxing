//
//  SearchBar.swift
//  TianXin
//
//  Created by SDS on 2020/9/22.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit

class SearchBar: UIView {

    override init(frame: CGRect) {
        super.init(frame: frame)
        setUI()
    }
  lazy  var textF:UITextField = {
    let ft = UITextField()
    ft.font = .pingfangSC(15)
    ft.tintColor = .blue
    ft.placeholder = "请输入你想要查找的关键字"
    return ft
    }()
    
    func setUI() {
        self.sdsSize = CGSize(width: 269.5, height: 28.5)
        self.layer.cornerRadius =  28.5*0.5

        self.backgroundColor = .Hex("#FFF7F8FC")
        //
        let imgv = UIImageView.init(image: UIImage(named: "seach"))
        self.addSubview(imgv)
        imgv.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.left.equalToSuperview().offset(33)
        }
        self.addSubview(textF)
        textF.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.left.equalTo(imgv.snp.right).offset(3)
        }
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
