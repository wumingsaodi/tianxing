//
//  HomeRecommendHeadFirst.swift
//  TianXin
//
//  Created by SDS on 2020/10/14.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit
import XRCarouselView
class HomeRecommendHeadFirst: UICollectionReusableView {
    static let headH:CGFloat = 364  //270 + 170
    let leftRightMargin:CGFloat = 10
    override init(frame: CGRect) {
        super.init(frame: frame)
        let  textV = UIView()
        textV.backgroundColor = .red
        self.addSubview(bannerView)
        bannerView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(leftRightMargin)
            make.right.equalToSuperview().offset(leftRightMargin)
            make.height.equalTo(168.5)
            make.top.equalToSuperview()
        }
        createTitleButs()
    }
    
    /**
     轮播图
     */
        lazy var bannerView:XRCarouselView = {
            let banner = SDSBanar().createBarnarView()
            banner.backgroundColor = .red
//    //        banner.imageClickBlock =  {[weak self](index) in
//    //            //
//    //        }
//
//            banner.placeholderImage = UIImage(named: "defualt")
//            banner.setPageColor(.white, andCurrentPageColor: .red)
//            banner.time = 1.5
            return banner
//            let  bannar = SDSBanar.share
//            return bannar
        }()
    func createTitleButs(){
        let leftBut = UIButton.createButWith( image: #imageLiteral(resourceName: "Game_sports")) {[weak self] (but) in
            self?.titleItemClick(inde: 0)
        }
        self.addSubview(leftBut)
      
        let rightbut  =  UIButton.createButWith( image: #imageLiteral(resourceName: "Game_caipiao")) {[weak self] (but) in
            self?.titleItemClick(inde: 5)
        }
        self.addSubview(rightbut)
        rightbut.snp.makeConstraints { (make) in
            make.right.equalToSuperview().offset(-leftRightMargin)
            make.top.equalTo(bannerView.snp.bottom).offset(24.5)
        }
        leftBut.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(leftRightMargin)
            make.bottom.equalTo(rightbut)
        }
        let images:[UIImage] = [#imageLiteral(resourceName: "Game_dianjing"),#imageLiteral(resourceName: "Game_qipai"),#imageLiteral(resourceName: "Game_zhenren"),#imageLiteral(resourceName: "Game_buyu")]
            let but1  =  UIButton.createButWith( image: images[0]) {[weak self] (but) in
                self?.titleItemClick(inde: 1)
            }
            self.addSubview(but1)
        let but2  =  UIButton.createButWith( image: images[1]) {[weak self] (but) in
            self?.titleItemClick(inde: 2)
        }
        //
        self.addSubview(but2)
        but2.snp.makeConstraints { (make) in
            make.left.equalTo(but1.snp.right).offset(3)
            make.top.equalTo(bannerView.snp.bottom).offset(24.5)
//                make.size.equalTo(CGSize(width: butw, height: buth))
        }
        but1.snp.makeConstraints { (make) in
            make.left.equalTo(leftBut.snp.right).offset(3)
            make.bottom.equalTo(but2)
//                make.size.equalTo(CGSize(width: butw, height: buth))
        }

        //
        let but3  =  UIButton.createButWith( image: images[2]) {[weak self] (but) in
            self?.titleItemClick(inde: 3)
        }
        self.addSubview(but3)
        but3.snp.makeConstraints { (make) in
            make.left.equalTo(but1)
            make.bottom.equalTo(rightbut)
//                make.size.equalTo(CGSize(width: butw, height: buth))
        }
        let but4  =  UIButton.createButWith( image: images[3]) {[weak self] (but) in
            self?.titleItemClick(inde: 4)
        }
        self.addSubview(but4)
        but4.snp.makeConstraints {  (make) in
            make.left.equalTo(but2)
            make.bottom.equalTo(rightbut)
//                make.size.equalTo(CGSize(width: butw, height: buth))
        }

                   
    
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}


//MARK: - actions
extension HomeRecommendHeadFirst {
    func titleItemClick(inde:Int){
        
    }
}



class SDSBanar: XRCarouselView {
    static var share:XRCarouselView = SDSBanar().createBarnarView()
    func createBarnarView()->XRCarouselView{
 
        let banner = XRCarouselView()
//        banner.imageClickBlock =  {[weak self](index) in
//            //
//        }
      
        banner.placeholderImage = UIImage(named: "defualt")
        banner.setPageColor(.white, andCurrentPageColor: .red)
        banner.time = 1.5
        LocalUserInfo.share.getBanar { (model) in
            banner.imageArray = model.index_banner.map({ (bannar) -> String in
                return  bannar.adUrl
            })
        }
        return banner
    }
}
