//
//  HomeCell.swift
//  TianXin
//
//  Created by SDS on 2020/9/21.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit

class HomeCell: UICollectionViewCell {
    @IBOutlet weak var guanKsnBut: UIButton!
    
    @IBOutlet weak var dizanBut: UIButton!
    @IBOutlet weak var detailL: UILabel!
    @IBOutlet weak var lastatLab: UIButton!
    @IBOutlet weak var bgIcon: UIImageView!
    @IBOutlet weak var dateL: UILabel!
    @IBOutlet weak var totalTimeL: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        totalTimeL.superview?.isHidden = true
    }
    func setModel(model :HomeItemModel){
        bgIcon.loadUrl(urlStr: model.pic, placeholder: "")
        detailL.text = model.name
        dizanBut.setTitle("\(model.loveNums)", for: .normal)
        lastatLab.setTitle("\(model.historyNum)", for: .normal)
    }
    @IBAction func dianZanButClick(_ sender: UIButton) {
        
    }
}
