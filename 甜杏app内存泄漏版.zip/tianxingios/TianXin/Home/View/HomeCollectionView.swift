//
//  HomeCollectionViewCell.swift
//  TianXin
//
//  Created by SDS on 2020/9/21.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit
import MJRefresh
class HomeCollectionView: UICollectionView {
  var dataSources:[HomeItemModel]?{
      didSet{
          self.reloadData()
      }
  }
  var headerText:String = ""
    static func createCell()->HomeCollectionView{
        let lay = UICollectionViewFlowLayout()
        let width = (KScreenW - 20 - 30)/2
               lay.itemSize = CGSize(width: width, height: 170)
        lay.headerReferenceSize = CGSize(width: KScreenW, height: 30)
//        lay.minimumLineSpacing = 10
        lay.sectionInset = UIEdgeInsets(top: 5, left: 10, bottom: 0, right: 10)
//        lay.minimumInteritemSpacing = 10
             let collect =  HomeCollectionView.init(frame: .zero, collectionViewLayout: lay)
               collect.delegate = collect
               collect.dataSource = collect
               let nib = UINib.init(nibName: "HomeCell", bundle: nil)
               
      let footer =  MJRefreshAutoGifFooter.init(refreshingBlock: {
            //
        })
        footer.setImages([UIImage(named: "shanglajiazai") as Any], for: MJRefreshState.idle)
        collect.mj_footer = footer
               collect.register(nib, forCellWithReuseIdentifier: HomeCell.className())
        collect.register(HomeCollectionCellHeader.self, forSupplementaryViewOfKind: elementKindSectionHeader, withReuseIdentifier: HomeCollectionCellHeader.className())
        collect.backgroundColor = .white
        return collect
    }

    func  collectHead(head:String,dataSours:[HomeItemModel]) {
        self.headerText = head
        self.dataSources = dataSours
    }
}
extension HomeCollectionView:UICollectionViewDelegate,UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        let count = self.dataSources?.count ?? 0
        return count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: HomeCell.className(), for: indexPath) as! HomeCell
        let model = dataSources![indexPath.row]
        cell.setModel(model:model)
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        let header = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: HomeCollectionCellHeader.className(), for: indexPath) as!  HomeCollectionCellHeader
        header.setHeadText(text: self.headerText)
        return header
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let parentvc  = self.getViewController()
        let model = self.dataSources![indexPath.row]
        let vc = HomeDetailVC(coverUrl: model.pic,id: "")
       
//        vc.url = model.
        parentvc?.navigationController?.pushViewController(vc, isNeedLogin: true, animated: true)
    }
}









class HomeCollectionCellHeader: UICollectionReusableView {
  lazy  var imgV:UIImageView = {
    let imgv = UIImageView()
    imgv.image = UIImage(named: "icon_button_xuanzhong")
    return imgv
    }()
    lazy var titleL:UILabel = {
        let lab = UILabel.createLabWith(title: "最新更新", titleColor: .Hex("#FF3B372B"), font:.pingfangSC(24))
        return lab
    }()
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(imgV)
        self.addSubview(titleL)
              titleL.snp.makeConstraints { (make) in
                  make.left.equalToSuperview().offset(12)
                  make.centerY.equalToSuperview()
              }
        
        imgV.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(-10)
            
            make.centerY.equalTo(titleL.snp.bottom)
        }
      
        let moreBut = UIButton.createButWith(title: "更多", titleColor: .Hex("#FF87827D"), font: .pingfangSC(13), image: UIImage(named: "Back_more")) { (_) in
            
        }
        moreBut.setButType(type: .imgRight, padding: 5)
        self.addSubview(moreBut)
        moreBut.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.right.equalToSuperview().offset(-10)
        }
    }
    func setHeadText(text:String) {
        titleL.text = text
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
