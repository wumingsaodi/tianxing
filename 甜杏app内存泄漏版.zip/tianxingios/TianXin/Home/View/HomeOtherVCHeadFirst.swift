//
//  HomeOtherVCHeadFirst.swift
//  TianXin
//
//  Created by SDS on 2020/10/14.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit
import XRCarouselView
class HomeOtherVCHeadFirst: UICollectionReusableView {
   static let headH:CGFloat = 250
    let leftRightMargin:CGFloat = 10
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func setUI(){
        self.addSubview(bannerView)
        bannerView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(leftRightMargin)
            make.right.equalToSuperview().offset(-leftRightMargin)
            make.top.equalToSuperview()
            make.height.equalTo(168.5)
        }
        self.addSubview(itemScrollV)
        itemScrollV.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalTo(bannerView.snp.bottom).offset(5)
            make.height.equalTo(80)
        }
    }
    /**
     轮播图
     */
        lazy var bannerView:XRCarouselView = {
            let  bannar = SDSBanar().createBarnarView()
            LocalUserInfo.share.getBanar { [weak self](model) in
                let titles = model.index_banner.map { (bannar) -> String in
                    return bannar.adUrl
                }
                bannar.imageArray = titles
            }
            bannar.backgroundColor = .yellow
            return bannar
        }()
    lazy var itemScrollV: HomeDownBannerItemView = {
        let itemscrollv = HomeDownBannerItemView()
        return itemscrollv
    }()
}
