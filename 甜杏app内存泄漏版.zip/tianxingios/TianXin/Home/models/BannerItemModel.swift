//
//  BannerModel.swift
//  TianXin
//
//  Created by SDS on 2020/10/5.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit
/**
 adCategoryId = "<null>";
 adDepict = "\U83e0\U841d\U5f71\U89c6\U9996\U9875";
 adNameSort = "<null>";
 adSettingId = 17;
 adStructure = "index_banner";
 adTemplate = "<null>";
 adUrl = "https://www.kok55.com/entry/register/?i_code=6429844";
 adverId = 42;
 adverName = "<null>";
 adverSort = "<null>";
 backgroundColor = "<null>";
 clientSide = 1;
 coverName = "<null>";
 coverUrl = "http://photo.qiushengtiyu.com/data/wwwroot/adFile//03d1fe76-c8e4-4037-99ee-9bc894df7873.gif";
 createTime = 1593599077000;
 detailId = 45;
 detailStatus = 1;
 endTime = "<null>";
 firstPicture = "<null>";
 format = 0;
 height = "<null>";
 id = 17;
 isPublic = 0;
 isStart = "<null>";
 mediumType = 1;
 name = "<null>";
 sort = 0;
 specificFormat = "<null>";
 startTime = "<null>";
 status = 1;
 type = "<null>";
 updateTime = 1593599077000;
 width = "<null>";
 */

class BannerItemModel: BaseModel {
   var adCategoryId = ""
   var  adDepict = ""
     var  adUrl = "";
     var  adverId = 42;
    var   coverUrl = "";
//  var  adNameSort = ""
//   var  adSettingId = 0
//  var  adStructure = "";
//  var  adTemplate = "";
// var   adverName = "<null>";
//  var  adverSort = "<null>";
// var   backgroundColor = "";
//  var  clientSide = 1;
//  var  coverName = "";
// var   coverUrl = "";
//   var createTime = 0;
//   var detailId = 0;
//   var detailStatus = 0;
//  var  endTime = "";
//  var  firstPicture = "";
//  var  format = 0;
//  var  height = "";
//  var  id = 17;
//  var  isPublic = 0;
//  var  isStart = "";
//   var mediumType = 1;
//   var name = "";
//  var  sort = 0;
//  var  specificFormat = "";
// var   startTime = "";
//  var  status = 0;
//  var  type = "";
//  var  updateTime = 0;
//  var  width = "";
}
