//
//  BannerListModel.swift
//  TianXin
//
//  Created by SDS on 2020/10/5.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit
class BannerListModel:BaseModel {
    var index_banner:[BannerItemModel] =  [BannerItemModel]()
    var my_account:[BannerItemModel] =  [BannerItemModel]()
    var video_detail:[BannerItemModel] =  [BannerItemModel]()
    var video_play:[BannerItemModel] =  [BannerItemModel]()
    var 测试广告位不要删:[BannerItemModel] =  [BannerItemModel]()
//    var my_account:[BannerItemModel] =  [BannerItemModel]()
}
