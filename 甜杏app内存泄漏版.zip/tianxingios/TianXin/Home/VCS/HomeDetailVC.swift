//
//  HomeDetailVC.swift
//  TianXin
//
//  Created by SDS on 2020/9/25.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit

class HomeDetailVC: UIViewController {
    let leftRightMargin:CGFloat = 10
    var coverImgUrl:String = ""
    var url:String =   "https://media.w3.org/2010/05/sintel/trailer.mp4"
    var playerVC:SDSPlayerVC!
    private var leftBut:UIButton!
    
    func setNav(){
//         self.navigationController?.navigationBar.isHidden = true
        self.navigationController?.navigationBar.isHidden = true
        leftBut = UIButton.createButWith(title: "ppsds", titleColor:.white, font: .pingfangSC(17), image: UIImage(named: "back_white")) {[weak self] (_) in
            self?.navigationController?.popViewController(animated: true)
        }
        leftBut.setButType(type: .imgLeft, padding: 8)
        sdsKeyWindow?.addSubview(leftBut)
        leftBut.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(20)
            make.top.equalToSuperview().offset(kStatueH)
            make.height.lessThanOrEqualTo(250)
        }
    }
    convenience init(coverUrl:String,id:String) {
          self.init()
        self.coverImgUrl = coverUrl
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setNav()
    }
    override func viewWillDisappear(_ animated: Bool) {
        leftBut?.removeFromSuperview()
    }
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.view.backgroundColor = .white
        
        if kAppdelegate.islogin() == false {
                 return
             }
        
        setUI()
     
    }
    
    func  setUI() {
       //视频播放器
        let palyerVC = SDSPlayerVC.init(url: url, viewChagetoSmallBlock: { (view) in
//            view.snp.remakeConstraints { (make) in
//            make.left.right.top.equalToSuperview()
//                       make.height.equalTo(240)
//            }
        }, coverImgUrl:self.coverImgUrl )
        self.playerVC = palyerVC
        self.addChild(palyerVC)
        self.view.addSubview(palyerVC.view)
        playerVC.view.snp.makeConstraints { (make) in
            make.left.right.top.equalToSuperview()
            make.height.equalTo(240)
        }
//        let titles = ["性感美女","人妻","中文字幕","无码"]
//               let topV = HomeDetialTopView.init(titles: titles)
//        self.view.addSubview(topV)
//        topV.snp.makeConstraints { (make) in
//                 make.left.right.equalToSuperview()
//            make.top.equalTo(playerVC.view.snp.bottom)
//                 make.height.equalTo(HomeDetialTopView.headerH)
//             }
        //
        self.view.addSubview(collectionView)
        collectionView.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalTo(playerVC.view.snp_bottomMargin).offset(5)
            make.bottom.equalToSuperview()
        }
      
        //
    }
    
    lazy var collectionView:UICollectionView = {
        let lay = UICollectionViewFlowLayout()
        lay.itemSize = CGSize(width: 175, height: 165)
        lay.sectionInset = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
        lay.minimumLineSpacing = 0
        lay.minimumInteritemSpacing = 10
        lay.headerReferenceSize = CGSize(width: KScreenW, height: HomeDetialTopView.headerH + 35 )
        
        let collect = UICollectionView.init(frame: .zero, collectionViewLayout: lay)
        collect.backgroundColor = .white
        collect.register(HomeDetailColletCell.self, forCellWithReuseIdentifier: HomeDetailColletCell.className())
        collect.delegate = self
        collect.dataSource = self
        collect.register(HomeDetailcollectHeader.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: HomeDetailcollectHeader.className())
        return collect
    }()

}
extension HomeDetailVC:UICollectionViewDelegate,UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 10
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: HomeDetailColletCell.className(), for: indexPath)
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        let header = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: HomeDetailcollectHeader.className(), for: indexPath)
        return header
    }
    
}









class HomeDetailcollectHeader: UICollectionReusableView {
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .white
        setUI()
    }
    func setUI(){
        let titles = ["性感美女","人妻","中文字幕","无码"]
        let topV = HomeDetialTopView.init(titles: titles)
        self.addSubview(topV)
        let imgv = UIImageView(image: UIImage(named: "icon_button_xuanzhong"))
        self.addSubview(imgv)
        self.addSubview(textLab)
        
        topV.snp.makeConstraints { (make) in
            make.left.right.top.equalToSuperview()
            make.height.equalTo(HomeDetialTopView.headerH)
        }
        
        imgv.snp.makeConstraints { (make) in
            make.centerX.equalTo(textLab.snp_leftMargin)
            make.centerY.equalTo(textLab.snp_bottomMargin)
        }
        textLab.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(10)
            make.top.equalTo(topV.snp_bottomMargin).offset(5)
        }
        
    }
  lazy  var textLab:UILabel = {
    let lab = UILabel.createLabWith(title: "相似推荐", titleColor: .Hex("#FF3B372B"),  font: .pingfangSC(17))
    return lab
    }()
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
class HomeDetailColletCell: UICollectionViewCell {
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUI()
    }
    lazy var imgv:UIImageView = {
        let imgv = UIImageView()
        imgv.image = UIImage(named: "defualt")
        imgv.contentMode = .scaleAspectFill
        imgv.cornor(conorType: .allCorners, reduis: 8)
        return imgv
    }()
    lazy var detailLab:UILabel = {
        let lab = UILabel.createLabWith(title: "直播性感小姐姐正在直播直播中直播中", titleColor: .Hex("#FF3B372B"), font: .pingfangSC(15))
        return lab
    }()
    func setUI(){
        self.contentView.addSubview(imgv)
        imgv.snp.makeConstraints { (make) in
            make.left.right.top.equalToSuperview()
            make.height.equalTo(124.5)
        }
        self.contentView.addSubview(detailLab)
        detailLab.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview().offset(5)
            make.top.equalTo(imgv.snp.bottom).offset(5)
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
