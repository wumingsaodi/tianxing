//
//  HomeSearchVC.swift
//  TianXin
//
//  Created by SDS on 2020/9/21.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit

class HomeSearchVC: SDSBaseVC {

  
    lazy var searchView:SearchBar = {
        let search = SearchBar()
        return search
    }()
    lazy var remenView:RemenSearch = {
        var titles:[String] = [String]()
        for i in 0..<10{
            titles.append("欧美")
        }
        let remen = RemenSearch.init(frame: .zero, titles: titles) {[weak self] (seletedText) in
            self!.searchView.textF.text = seletedText
        }
        return remen
    }()
    lazy var tableV:SDSTableView = {
        let table = SDSTableView.CreateTableView().sdsRegisterCell(cellClass: "searchTableCell", isNib: true, cellBlock: { (index, cell) in
            
        }, height: { (index) -> CGFloat in
            return 110
        }).sdsNumOfRows(block: { (num) -> Int in
            return 10
        }).sdsRegisterHeader(headerClass: "UITableViewHeaderFooterView", headerBlock: { (_, header) in
            let lab = UILabel.createLabWith(title: "以为你搜索23条记录", titleColor: .Hex("#FF3C3729"), font: .pingfangSC(20), aligment: .center)
            header.addSubview(lab)
            header.contentView.backgroundColor = .white
            lab.snp.makeConstraints { (make) in
                make.edges.equalToSuperview()
            }
        }, height: { (_) -> CGFloat in
            return 44
        }).sdsDidSelectCell { (indexpath) in
        
        }
        table.isHidden = true
        return table
    }()
    override func viewDidLoad() {
          super.viewDidLoad()
        self.view.backgroundColor = .Hex("#FFF7F8FC")
          setNav()
        //
        self.view.addSubview(remenView)
        remenView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(KnavHeight + 10)
            make.left.right.bottom.equalToSuperview()
        }
        self.view.addSubview(tableV)
        tableV.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.top.equalToSuperview().offset(KnavHeight + 15)
        }
      }
    func setNav() {
        self.navigationController?.navigationBar.addSubview(searchView)
        searchView.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
            make.size.equalTo(searchView.sdsSize)
        }
        let but = UIButton.createButWith(title: "搜索", titleColor: UIColor.Hex("#FF87827D"),font: .pingfangSC(15)) { (_) in
            self.remenView.isHidden = true
            self.tableV.isHidden = false
            //网络请求
        }
        self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(customView: but)
    }
}
