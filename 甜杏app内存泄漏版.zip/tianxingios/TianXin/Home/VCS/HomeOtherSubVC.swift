//
//  HomeOtherSubVC.swift
//  TianXin
//
//  Created by SDS on 2020/10/14.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit
import MJRefresh
class HomeOtherSubVC: SDSBaseVC {
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.addSubview(collectionv)
        collectionv.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    lazy var collectionv:UICollectionView = {
        let lay  = UICollectionViewFlowLayout()
        lay.sectionInset = UIEdgeInsets(top: 5, left: 10, bottom: 0, right: 10)
        let collevtv = UICollectionView.init(frame: .zero, collectionViewLayout: lay)
        collevtv.delegate = self
        collevtv.dataSource = self
        collevtv.register(DefultCell.self, forCellWithReuseIdentifier: DefultCell.className())
        
        collevtv.register(UINib(nibName: "HomeCell", bundle: nil), forCellWithReuseIdentifier: HomeCell.className())
        //header
        collevtv.register(HomeOtherVCHeadFirst.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: HomeOtherVCHeadFirst.className())
        
        collevtv.register(HomeCollectionCellHeader.self, forSupplementaryViewOfKind:UICollectionView.elementKindSectionHeader, withReuseIdentifier: HomeCollectionCellHeader.className())
        
        collevtv.backgroundColor = .white
        collevtv.mj_footer = MJRefreshAutoFooter.init(refreshingBlock: {
            [weak self] in
            
        })
        
        return collevtv
    }()
}


//MARK: - datasours delegate
extension HomeOtherSubVC : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if section == 0 {
            return 1
        }
        return  4
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return  2
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if indexPath.section == 0 {
            return CGSize(width: 1, height: 1)
        }
        let width = (KScreenW - 20 - 30)/2
        return CGSize(width: width, height: 170)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        if section == 0 {
            return  CGSize(width: KScreenW, height: HomeOtherVCHeadFirst.headH)
        }
        return  CGSize(width: KScreenW, height: 30)
    }
//   collectionviewlayout
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if indexPath.section == 0 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: DefultCell.className(), for: indexPath)
            return cell //UICollectionViewCell()
        }else{
            let cell  = collectionView.dequeueReusableCell(withReuseIdentifier: HomeCell.className(), for: indexPath) as! HomeCell
            return cell
        }
       
    }
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        if kind == UICollectionView.elementKindSectionFooter {
//            return  UIView() as! UICollectionReusableView
        }else{
            if indexPath.section == 0 {
                let header = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: HomeOtherVCHeadFirst.className(), for: indexPath) as! HomeOtherVCHeadFirst
                return  header
            }else{
                let header = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: HomeCollectionCellHeader.className(), for: indexPath) as! HomeCollectionCellHeader
                return  header
            }
        }
       return UICollectionReusableView()
       
    }
    
}

class DefultCell: UICollectionViewCell {
}
