
//
//  MineTaskCenterVC.swift
//  TianXin
//
//  Created by SDS on 2020/10/10.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit

class MineTaskCenterVC: SDSBaseVC {
    let headers:[String] = ["新手任务","日常任务","推广任务","推广小帖士"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "任务中心"
        setUI()
    }
    func  setUI(){
        self.view.addSubview(tableView)
        tableView.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalToSuperview().offset(KnavHeight)
            make.bottom.equalToSuperview()
        }
    }

    lazy var tableView:UITableView = {
        let tab = UITableView.init(frame: .zero, style: .grouped)
        tab.backgroundColor = baseVCBackGroudColor_grayWhite
        tab.dataSource = self
        tab.delegate = self
        tab.register(UINib.init(nibName: "MineTaskHeaderFirst", bundle: nil), forHeaderFooterViewReuseIdentifier: MineTaskHeaderFirst.className())
        tab.register(UINib.init(nibName: "MineTaskHeadersecond", bundle: nil), forHeaderFooterViewReuseIdentifier: MineTaskHeadersecond.className())
        tab.register(UINib.init(nibName: "MineTaskCell", bundle: nil), forCellReuseIdentifier: MineTaskCell.className())
        return tab
    }()
}
extension MineTaskCenterVC:UITableViewDataSource,UITableViewDelegate{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 5
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return 1
        } else  if section == 1 {
            return 2
        }
        else  if section == 2 {
            return 2
        }
        else  if section == 3 {
            return 5
        }
        else  if section == 4 {
            return 1
        }
        return 0
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 3 {
            return 83.5
        }else if indexPath.section == 0 {
            return 0.01
        }
        return 70
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if  section == 0 {
            return 510
        }
        return  44
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            let cell = UITableViewCell.init()
            return cell
        }
        let cell = tableView.dequeueReusableCell(withIdentifier: MineTaskCell.className()) as! MineTaskCell
        return cell
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        if section == 0 {
            let head = tableView.dequeueReusableHeaderFooterView(withIdentifier:  MineTaskHeaderFirst.className()) as! MineTaskHeaderFirst
            return head
        }
        let realSection = section - 1
        let  head = tableView.dequeueReusableHeaderFooterView(withIdentifier: MineTaskHeadersecond.className()) as! MineTaskHeadersecond
        head.setTitle(title: headers[realSection])
        return  head
    }
    
}
