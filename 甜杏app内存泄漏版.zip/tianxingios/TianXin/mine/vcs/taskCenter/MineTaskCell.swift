//
//  MineTaskCell.swift
//  TianXin
//
//  Created by SDS on 2020/10/10.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit

class MineTaskCell: UITableViewCell {
    let blackTitleColor:UIColor = .Hex("484848")
    let drakblackTitleColor:UIColor =  .Hex("#4E4E4E")
    let detailGrayColor:UIColor = .Hex("#AEAAA8")
    let defualtTitleFont:UIFont =  .pingfangSC(16)
    let smallTitleFont:UIFont  = .pingfangSC(14)
    @IBOutlet weak var detailLab: UILabel!
    @IBOutlet weak var kokImgv: UIImageView!
    @IBOutlet weak var addCoinLab: UILabel!
    @IBOutlet weak var iconV: UIImageView!
    @IBOutlet weak var titleLab: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
  
//    override func setSelected(_ selected: Bool, animated: Bool) {
//        super.setSelected(selected, animated: animated)
//
//        // Configure the view for the selected state
//    }
    
}
