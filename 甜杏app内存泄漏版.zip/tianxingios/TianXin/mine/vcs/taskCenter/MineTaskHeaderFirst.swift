//
//  MineTaskHeaderFirst.swift
//  TianXin
//
//  Created by SDS on 2020/10/10.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit

class MineTaskHeaderFirst: UITableViewHeaderFooterView {
    @IBOutlet weak var activityDetailBut: SDSButton!
    @IBOutlet weak var checkDayLab: UILabel!
    @IBOutlet weak var CheckInBut: UIButton!
    
    @IBOutlet weak var butsV: UIView!
    @IBOutlet weak var adImgV: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        activityDetailBut.cornor(conorType: UIRectCorner.init(arrayLiteral: .bottomLeft,.bottomRight), reduis: 5)
        adImgV.isUserInteractionEnabled = true
        adImgV.rx.tapGesture().subscribe(onNext:{ _ in
            //
        }).disposed(by: rx.disposeBag)
        
    }
    @IBAction func CheckInButClick(_ sender: UIButton) {
    }
    @IBAction func activityDetailClick(_ sender: SDSButton) {
    }
    
    
}
