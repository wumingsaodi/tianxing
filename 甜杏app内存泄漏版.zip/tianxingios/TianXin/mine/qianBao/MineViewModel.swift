//
//  MineViewModel.swift
//  TianXin
//
//  Created by SDS on 2020/10/7.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit

class MineViewModel: NSObject {

}
