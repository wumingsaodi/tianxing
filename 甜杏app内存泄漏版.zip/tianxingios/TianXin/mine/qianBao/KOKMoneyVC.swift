//
//  KOKMoneyVC.swift
//  TianXin
//
//  Created by SDS on 2020/10/1.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit

class KOKMoneyVC: SDSBaseVC {
    @IBOutlet weak var tianXingMoneyLab: UILabel!
    @IBOutlet weak var kokMoneyLab: UILabel!
    @IBOutlet weak var sureBut: UIButton!
    
    @IBOutlet weak var moneyF: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        self.sureBut.cornor(conorType: .allCorners, reduis: 19)
        let backimg = UIImage.CreateGradienImg(colors: [.Hex("#FFFFD26B"),.Hex("#FFF8944B")])
        sureBut.setBackgroundImage(backimg, for: .normal)
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setWhiteBackImg(title:"转账")
    }
    @IBAction func sureButClick(_ sender: UIButton) {
    }

}
