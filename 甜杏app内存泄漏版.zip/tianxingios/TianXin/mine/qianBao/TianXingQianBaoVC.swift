//
//  TianXingQianBaoVC.swift
//  TianXin
//
//  Created by SDS on 2020/9/30.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit

class TianXingQianBaoVC: SDSBaseVC {

    @IBOutlet weak var selectedLine: UIView!
    @IBOutlet weak var helpBut: UIButton!
    @IBOutlet weak var nodataV: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
         self.helpBut.backgroundColor = UIColor.init(white: 1, alpha: 0.33)
        helpBut.cornor(conorType: UIRectCorner(arrayLiteral: .topLeft,.bottomLeft), reduis: 17)
//        self.setBackImg(name: "back_white", hideNav: true)
        self.view.addSubview(tableView)
        tableView.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview().offset(-kBottomSafeH)
            make.top.equalTo(selectedLine.snp.bottom).offset(3)
        }

    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setWhiteBackImg( hideNav: true)
    }
    lazy var tableView:SDSTableView = {
        let tab = SDSTableView.CreateTableView()
//        tab.backgroundColor = .yellow
        return tab
    }()
 
    @IBAction func zhuanzhangButClick(_ sender: UIButton) {
    }
    @IBAction func chongzhiButClick(_ sender: UIButton) {
    }
    

     @IBAction func helpBuTclick(_ sender: UIButton) {
     }
    @IBAction func keFuButClick(_ sender: UIButton) {
    }
    // MARK: - Navigation

    @IBAction func titleButClick(_ sender: UIButton) {
       if self.selectedLine.center.x == sender.center.x
        {
         return
        }
        UIView.animate(withDuration: 0.5) {
            self.selectedLine.center.x = sender.center.x
        }
    }
    
}
