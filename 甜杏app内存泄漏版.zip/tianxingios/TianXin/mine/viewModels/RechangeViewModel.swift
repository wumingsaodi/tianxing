//
//  RechangeViewModel.swift
//  TianXin
//
//  Created by SDS on 2020/10/13.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit

class RechangeViewModel: NSObject {
    func requistGetPlayTypeList(success:@escaping(_ models:[PayTypeModel?])->Void){
        NetWorkingHelper.normalPost(url: api_getPayTypes, params: [:]) { (dict) in
            guard let dataDict = dict["data"] as? Array<Any> ,let models = [PayTypeModel].deserialize(from: dataDict) else{
                return
            }
            success(models)
        }
    }
    func requistPayDownOrder(tpaysetid:String,money:String,success:@escaping()->Void) {
        NetWorkingHelper.normalPost(url: api_payDwonOrder, params: ["tpaysetid":tpaysetid ,"money":money]) { (dict) in
            success()
        }
    }
}
