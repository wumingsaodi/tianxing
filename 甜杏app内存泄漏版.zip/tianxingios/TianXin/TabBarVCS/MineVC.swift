//
//  MineVC.swift
//  TianXin
//
//  Created by SDS on 2020/9/18.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit
class MineVC: SDSBaseVC {
    let leftRightMargin:CGFloat = 10
    override func viewDidLoad() {
        super.viewDidLoad()
        setUI()
        LocalUserInfo.share.updateLoginSate {[weak self] (islogin) in
            if islogin {
                self?.loginedView.isHidden = false
                self?.nologinV.isHidden = true
                LocalUserInfo.share.getLoginInfo {[weak self] (model) in
                    guard let model = model else{
                        self?.nologinV.isHidden = false
                        self?.loginedView.isHidden = true
                        return
                    }
                    self?.nameL.text = model.nickName
                    self?.iconV.loadUrl(urlStr: model.userLogo, placeholder: "defult_user")
                    
                  
                }
            }else{
                self?.iconV.image = #imageLiteral(resourceName: "icon_Avatar")
//                self?.iconV.image = UIImage(named: "icon_Avatar")
                self?.nologinV.isHidden = false
                self?.loginedView .isHidden = true
            }
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = true
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.navigationBar.isHidden = false
    }
    func setUI(){
        let headV = UIView()
        headV.backgroundColor = .white
        self.view.addSubview(headV)
        headV.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(leftRightMargin)
            make.right.equalToSuperview().offset(-leftRightMargin)
            make.top.equalToSuperview()
            make.height.equalTo(150)
        }
        headV.addSubview(iconV)
        iconV.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.left.equalToSuperview().offset(16.5)
            make.size.equalTo(CGSize(width: 72, height: 72))
        }
        headV.addSubview(nologinV)
        nologinV.isHidden = true
        nologinV.snp.makeConstraints { (make) in
            make.top.right.bottom.equalToSuperview()
            make.left.equalTo(iconV.snp.right).offset(15)
        }
        //
        headV.addSubview(loginedView)
        loginedView.isHidden = false
        loginedView.snp.makeConstraints { (make) in
            make.top.right.bottom.equalToSuperview()
            make.left.equalTo(iconV.snp.right).offset(15)
        }
        //
        let monyViews = cretatmoneyViews()
        self.view.addSubview(monyViews)
        monyViews.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(leftRightMargin)
            make.right.equalToSuperview().offset(-leftRightMargin)
            make.top.equalTo(headV.snp.bottom).offset(10)
            make.height.equalTo(168)
        }
        //
        let itemsv = createitemsView()
        self.view.addSubview(itemsv)
        itemsv.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(leftRightMargin)
            make.right.equalToSuperview().offset(-leftRightMargin)
            make.top.equalTo(monyViews.snp.bottom).offset(10)
            make.height.equalTo(90)
        }
        //
        self.view.addSubview(tableView)
        tableView.isScrollEnabled = false
        tableView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(leftRightMargin)
            make.right.equalToSuperview().offset(-leftRightMargin)
            make.top.equalTo(itemsv.snp.bottom).offset(10)
            make.height.equalTo(44*3)
            //            make.bottom.equalToSuperview()
        }

    }
    func createitemsView()->UIView{
        let bgv = UIView()
        bgv.backgroundColor = .white
        bgv.cornor(conorType: .allCorners, reduis: 5)
        let titles = ["我要推广","充值中心","任务中心","我的收藏"]
        let imgNames = ["icon_Promote","icon_recharge centre","icon_task","icon_Collect"]
//       let vc  =    R.storyboard.topic.movieFavoritesViewController
        
        let  shoucangvc = MovieFavoritesViewController.instanceFrom(storyboard: "Topic")
        let vcs:[UIViewController] = [TuiguangVC(),RechargeVC(),MineTaskCenterVC(),shoucangvc]
        let butw:CGFloat = (KScreenW - 20)/4
        var x:CGFloat = 0
        for i in 0..<titles.count {
            let but = UIButton.createButWith(title: titles[i], titleColor: .Hex("#FF87827D"), font: .pingfangSC(14), image: UIImage(named: imgNames[i])) { (_) in
                self.navigationController?.pushViewController(vcs[i],isNeedLogin: true, animated: true)
            }
            
            but.setButType(type: .imgTop, padding: 5)
            bgv.addSubview(but)
            but.snp.makeConstraints { (make) in
                make.centerY.equalToSuperview()
                make.left.equalToSuperview().offset(x)
            }
            x += butw
        }
        
        return bgv
    }
    
    func  cretatmoneyViews() -> UIView {
        let bgv = UIView()
        bgv.backgroundColor = .white
        bgv.cornor(conorType: .allCorners, reduis: 5)
        let tianMoneyv =   createMoneyView(backgroudImg: UIImage(named: "qianbao0")!, detailTxt: "甜杏钱包（元）", isTianxin: true)
        bgv.addSubview(tianMoneyv)
        tianMoneyv.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(8)
            make.centerX.equalToSuperview()
            make.size.equalTo(CGSize(width: 300, height: 68))
        }
        let kokMoneyv =   createMoneyView(backgroudImg: UIImage(named: "qianbao1")!, detailTxt: "KOK体育钱包（元）", isTianxin: false)
        bgv.addSubview(kokMoneyv)
        kokMoneyv.snp.makeConstraints { (make) in
            make.top.equalTo(tianMoneyv.snp.bottom).offset(9)
            make.centerX.equalToSuperview()
            make.size.equalTo(CGSize(width: 300, height: 68))
        }
        return bgv
    }
    func loginStatueChange(islogin:Bool){
        if islogin {
            nologinV.isHidden = true
            loginedView.isHidden = false
        }else{
            nologinV.isHidden = false
            loginedView.isHidden = true
        }
    }
    func createMoneyView(backgroudImg:UIImage,detailTxt:String,isTianxin:Bool)->UIImageView{
        let bgv = UIImageView()
        bgv.isUserInteractionEnabled = true
        var tap:UITapGestureRecognizer!
        if isTianxin {
            tap = UITapGestureRecognizer.init(target: self, action: #selector(jumpToTianXingMoneyVC))
        }else
        {
            tap = UITapGestureRecognizer.init(target: self, action: #selector(jumpToKOKMoneyVC))
        }
        bgv.addGestureRecognizer(tap)
        bgv.contentMode = .scaleToFill
        bgv.image = backgroudImg
        
        let toplab = UILabel.createLabWith(title: "0", titleColor: .white, font: .pingfangSC(20))
        if isTianxin {
            tianxinMoneyL = toplab
        }else{
            kOKmoneyL = toplab
        }
        bgv.addSubview(toplab)
        toplab.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(75)
            make.top.equalToSuperview().offset(8)
        }
        let detailL = UILabel.createLabWith(title: detailTxt, titleColor: .white, font: .pingfangSC(5))
        bgv.addSubview(detailL)
        detailL.snp.makeConstraints { (make) in
            make.left.equalTo(toplab)
            make.top.equalTo(toplab.snp.bottom).offset(5)
        }
        return bgv
    }
    
    lazy var iconV:UIImageView = {
        let imgv = UIImageView()
        imgv.cornor(conorType: .allCorners, reduis: 36)
        imgv.image = UIImage.init(named: "icon_Avatar")
        return imgv
    }()
    lazy var nologinV:UIView = {
        let view = UIView()
        let but = UIButton.createButWith(title: "登陆/注册", titleColor: mainYellowColor, font: .pingfangSC(18)){ (_) in
            let loginVC = LoginVC()
            self.navigationController?.pushViewController(loginVC, animated: true)
        }
        but.cornor(conorType: .allCorners, reduis: 15.5,borderWith: 1,borderColor: mainYellowColor)
        view.addSubview(but)
        but.snp.makeConstraints { (make) in
            make.left.equalToSuperview()
            make.top.equalToSuperview().offset(50)
            make.size.equalTo(CGSize(width: 117.5, height: 31))
        }
        let lab = UILabel.createLabWith(title: "登陆后获取更多精彩内容哦～", titleColor: .Hex("#FF686868"), font: .pingfangSC(15))
        view.addSubview(lab)
        lab.snp.makeConstraints { (make) in
            make.left.equalTo(but)
            make.top.equalTo(but.snp.bottom).offset(5)
            //            make.right.equalToSuperview()
            //            make.bottom.equalToSuperview()
        }
        return view
    }()
    lazy var nameL:UILabel = {
        let lab = UILabel.createLabWith(title: "", titleColor: .Hex("#FF918C88"), font: .pingfangSC(22))
        return lab
    }()
    lazy var loginedView:UIView = {
        let view = UIView()
        view.addSubview(nameL)
        nameL.snp.makeConstraints { (make) in
            make.left.centerY.equalToSuperview()
        }
        let but = UIButton.createButWith( image: UIImage(named: "Back_more")) { (_) in
            let vc = mineSettingVC()
            self.navigationController?.pushViewController(vc, animated: true)
        }
        view.addSubview(but)
        but.snp.makeConstraints { (make) in
            make.right.equalToSuperview().offset(-20)
            make.top.bottom.equalToSuperview()
            make.width.equalTo(50)
        }
        return view
    }()
    var tianxinMoneyL:UILabel!
    var kOKmoneyL:UILabel!
    lazy var tableView:SDSTableView = {
        let tab = SDSTableView.CreateTableView().sdsNumOfRows(block: { (_) -> Int in
            return 3
        }) .sdsRegisterCell(cellClass: mineTableCell.className(), cellBlock: { (indepath, cell) in
            let ncell = cell as! mineTableCell
            if indepath.row == 0 {
                ncell.setcell(imgName: "icon_kefu", text: "联系客服")
            }else if indepath.row == 1 {
                ncell.setcell(imgName: "icon_setting", text: "系统设置")
            }else if indepath.row == 2 {
                ncell.setcell(imgName: "icon_about us", text: "关于我们")
            }
        },height: { (_) -> CGFloat in
            return 44
        }).sdsDidSelectCell { (indepath) in
            if indepath.row == 0 {//联系客服
                let vc = KefuVC()
                self.navigationController?.pushViewController(vc, animated: true)
            }
            else if indepath.row == 1 {//系统设置
                let vc = SettingVC()
                self.navigationController?.pushViewController(vc,isNeedLogin: true, animated: true)
            }else if indepath.row == 2 {//关于我们
                let vc = AboutUS()
                self.navigationController?.pushViewController(vc, animated: true)
            }
        }
        return tab
    }()
}


extension MineVC {
    @objc   func   jumpToTianXingMoneyVC(){
        let vc = TianXingQianBaoVC.init(nibName: "TianXingQianBaoVC", bundle: nil)
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @objc   func   jumpToKOKMoneyVC(){
        let vc = KOKMoneyVC.init(nibName: "KOKMoneyVC", bundle: nil)
               self.navigationController?.pushViewController(vc, animated: true)
    }
}







class  mineTableCell: UITableViewCell {
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.contentView.backgroundColor = .white
        setUI()
    }
    func setcell(imgName:String,text:String)  {
        self.imgv.image = UIImage(named: imgName)
        self.textL.text = text
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    lazy  var imgv:UIImageView = {
        let imgv = UIImageView()
        return imgv
    }()
    lazy var textL:UILabel  = {
        let lab = UILabel.createLabWith(title: "", titleColor: .Hex("#FF87827D"), font: .pingfangSC(15))
        return lab
    }()
    func setUI() {
        //
        self.contentView.addSubview(imgv)
        imgv.snp.makeConstraints { (make) in
            make.left.equalTo(26.5)
            make.centerY.equalToSuperview()
            make.size.equalTo(CGSize(width: 34.5, height: 34.5))
        }
        //
        self.contentView.addSubview(textL)
        
        textL.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.left.equalTo(imgv.snp.right).offset(15)
        }
        //
        let subimgv = UIImageView(image: UIImage(named: "Back_more"))
        self.contentView.addSubview(subimgv)
        subimgv.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.right.equalToSuperview().offset(-20)
        }
    }
    
}


