//
//  HomeVC.swift
//  TianXin
//
//  Created by SDS on 2020/9/18.
//  Copyright © 2020 SDS. All rights reserved.
//

import UIKit
import XRCarouselView
//import LLCycleScrollView
class HomeVC: UIViewController {
    var childVcs:[UIViewController] =  [homeIndexVC]()
    lazy var homevm :HomeViewModel = {
      let vm = HomeViewModel()
        return vm
    }()
  
    lazy var  topView:HometopSearchView = {
        let top = HometopSearchView()
        return top
    }()
    lazy var titleView:SDSScrollTitlesView = {
        let titles =  ["推荐","国产","中文无码"]   // ["关注","推荐","游戏","国产","中文无码"]
        let width:CGFloat =  100  //(KScreenW - 40) / CGFloat(titles.count)
        let view = SDSScrollTitlesView(ttles: titles, width: width) {[weak self] (index, cell) in
            self?.vcsCollectionv.scollToIndex(index: index)
        }
        return view
    }()

    lazy var itemScrollorViews:HomeDownBannerItemView = {
        let itemv = HomeDownBannerItemView()
        return itemv
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = true
        self.view.backgroundColor = .white
        setUI()
        homevm.RequistHomeIndex {[weak self] in
            guard  let model =  self?.homevm.homeModel else{
                return
            }
            var  titles:[String] = ["推荐"]
            titles.append(contentsOf: model.type.map({ (iteem) -> String in
                return iteem.type
            }))
            self?.titleView.titles = titles
            var vcs:[UIViewController] = [UIViewController]()
            for i in 0..<titles.count{
                if i == 0 {
                  let recomemnt =  HomeRecomentVC()
                    recomemnt.indexModel = model
                    vcs.append(recomemnt)
                }else{
                    let othervc = HomeOtherSubVC()
                    vcs.append(othervc)
                }
            }
            self?.childVcs = vcs
            self?.vcsCollectionv.VCs = vcs
        }
        self.perform(#selector(FirstScroll), with: nil, afterDelay: 0.25)
    }
    
    func  setUI(){
        self.view.addSubview(topView)
        topView.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalToSuperview().offset(kStatueH + 15 )
            make.height.equalTo(30)
        }
        //
         self.view.addSubview(titleView)

        titleView.snp.makeConstraints { (make) in
            make.left.equalToSuperview()
            make.right.equalToSuperview() //.offset(-40)
            make.top.equalTo(topView.snp.bottom).offset(8)
            make.height.equalTo(30)
        }

        //
        self.view.addSubview(vcsCollectionv)
        vcsCollectionv.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview().offset(-kBottomSafeH)
            make.top.equalTo(titleView.snp.bottom).offset(5)
            
        }
    }
    lazy var vcsCollectionv:SDSScrollColltionView = {
       let vc = HomeRecomentVC()
        self.childVcs.append(vc)
        self.childVcs.append(HomeOtherSubVC())
        let collv = SDSScrollColltionView(VCs: self.childVcs) {[weak self] (index) in
            self?.titleView.scollToIndex(index: index)
        }
        return collv
    }()
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = true
        navigationItem.backButtonTitle = ""
        
    }
    @objc  func  FirstScroll(){
        self.titleView.scollToIndex(index: 0)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.navigationBar.isHidden = false
//        self.hidesBottomBarWhenPushed = true
    }
    

}


